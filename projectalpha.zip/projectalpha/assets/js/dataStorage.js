// display panel
function panelFunction() {
  document.getElementById("id01").style.display = "block";
}
// Session storage clicker
function clickSessionCounter() {
    if(typeof(Storage) !== "undefined") {
        if (sessionStorage.clickcount) {
            sessionStorage.clickcount = Number(sessionStorage.clickcount)+1;
        } else {
            sessionStorage.clickcount = 1;
        }
        document.getElementById("result01").innerHTML = "You have clicked the button " + sessionStorage.clickcount + " time(s) in this session.";
    } else {
        document.getElementById("result01").innerHTML = "Sorry, your browser does not support web storage...";
    }
}
// Local storage clicker
function clickCounter() {
    if(typeof(Storage) !== "undefined") {
        if (localStorage.clickcount) {
            localStorage.clickcount = Number(localStorage.clickcount)+1;
        } else {
            localStorage.clickcount = 1;
        }
        document.getElementById("result02").innerHTML = "You have clicked the button " + localStorage.clickcount + " time(s) in multiple sessions.";
    } else {
        document.getElementById("result02").innerHTML = "Sorry, your browser does not support web storage...";
    }
}
// Toggle the results table OFF by default
$( document ).ready(function() {
  $("#resultsTable").toggle();
});
// Toggle the mobile results table OFF by default
$( document ).ready(function() {
  $("#mResultsTable").toggle();
});
// Function to submit input box data values into localStorage
function submission() {
  if(typeof(Storage) !== "undefined") {
    //Storing data:
      var data01 = $("#text01-01").val(); localStorage.setItem("text01-01", data01);
      var data02 = $("#text01-02").val(); localStorage.setItem("text01-02", data02);
      var data03 = $("#text01-03").val(); localStorage.setItem("text01-03", data03);
      var data04 = $("#text01-04").val(); localStorage.setItem("text01-04", data04);

      var data05 = $("#text02-01").val(); localStorage.setItem("text02-01", data05);
      var data06 = $("#text02-02").val(); localStorage.setItem("text02-02", data06);
      var data07 = $("#text02-03").val(); localStorage.setItem("text02-03", data07);
      var data08 = $("#text02-04").val(); localStorage.setItem("text02-04", data08);

      var data09 = $("#text03-01").val(); localStorage.setItem("text03-01", data09);
      var data10 = $("#text03-02").val(); localStorage.setItem("text03-02", data10);
      var data11 = $("#text03-03").val(); localStorage.setItem("text03-03", data11);
      var data12 = $("#text03-04").val(); localStorage.setItem("text03-04", data12);

      var data13 = $("#text04-01").val(); localStorage.setItem("text04-01", data13);
      var data14 = $("#text04-02").val(); localStorage.setItem("text04-02", data14);
      var data15 = $("#text04-03").val(); localStorage.setItem("text04-03", data15);
      var data16 = $("#text04-04").val(); localStorage.setItem("text04-04", data16);

    } else {
      alert("Incorrect.");
  }
}
// Function to submit input box data values into localStorage
function mSubmission() {
  if(typeof(Storage) !== "undefined") {
    //Storing data:
      var data01 = $("#mtext01-01").val(); localStorage.setItem("mtext01-01", data01);
      var data02 = $("#mtext01-02").val(); localStorage.setItem("mtext01-02", data02);
      var data03 = $("#mtext01-03").val(); localStorage.setItem("mtext01-03", data03);
      var data04 = $("#mtext01-04").val(); localStorage.setItem("mtext01-04", data04);

      var data05 = $("#mtext02-01").val(); localStorage.setItem("mtext02-01", data05);
      var data06 = $("#mtext02-02").val(); localStorage.setItem("mtext02-02", data06);
      var data07 = $("#mtext02-03").val(); localStorage.setItem("mtext02-03", data07);
      var data08 = $("#mtext02-04").val(); localStorage.setItem("mtext02-04", data08);

      var data09 = $("#mtext03-01").val(); localStorage.setItem("mtext03-01", data09);
      var data10 = $("#mtext03-02").val(); localStorage.setItem("mtext03-02", data10);
      var data11 = $("#mtext03-03").val(); localStorage.setItem("mtext03-03", data11);
      var data12 = $("#mtext03-04").val(); localStorage.setItem("mtext03-04", data12);

      var data13 = $("#mtext04-01").val(); localStorage.setItem("mtext04-01", data13);
      var data14 = $("#mtext04-02").val(); localStorage.setItem("mtext04-02", data14);
      var data15 = $("#mtext04-03").val(); localStorage.setItem("mtext04-03", data15);
      var data16 = $("#mtext04-04").val(); localStorage.setItem("mtext04-04", data16);

    } else {
      alert("Incorrect.");
  }
}

// Function to get input box data values from localStorage and display them in the table
function storage() {
  if(typeof(Storage) !== "undefined") {
    //Toggle the results table back to be shown
    $("#resultsTable").toggle();
    //Retrieving data:
      document.getElementById("display01-01").innerHTML = localStorage.getItem("text01-01");
      document.getElementById("display01-02").innerHTML = localStorage.getItem("text01-02");
      document.getElementById("display01-03").innerHTML = localStorage.getItem("text01-03");
      document.getElementById("display01-04").innerHTML = localStorage.getItem("text01-04");

      document.getElementById("display02-01").innerHTML = localStorage.getItem("text02-01");
      document.getElementById("display02-02").innerHTML = localStorage.getItem("text02-02");
      document.getElementById("display02-03").innerHTML = localStorage.getItem("text02-03");
      document.getElementById("display02-04").innerHTML = localStorage.getItem("text02-04");

      document.getElementById("display03-01").innerHTML = localStorage.getItem("text03-01");
      document.getElementById("display03-02").innerHTML = localStorage.getItem("text03-02");
      document.getElementById("display03-03").innerHTML = localStorage.getItem("text03-03");
      document.getElementById("display03-04").innerHTML = localStorage.getItem("text03-04");

      document.getElementById("display04-01").innerHTML = localStorage.getItem("text04-01");
      document.getElementById("display04-02").innerHTML = localStorage.getItem("text04-02");
      document.getElementById("display04-03").innerHTML = localStorage.getItem("text04-03");
      document.getElementById("display04-04").innerHTML = localStorage.getItem("text04-04");

    } else {
      alert("Incorrect.");
  }
}
// Function to get input box data values from localStorage and display them in the table
function mStorage() {
  if(typeof(Storage) !== "undefined") {
    //Toggle the results table back to be shown
    $("#mResultsTable").toggle();
    //Retrieving data:
      document.getElementById("mdisplay01-01").innerHTML = localStorage.getItem("mtext01-01");
      document.getElementById("mdisplay01-02").innerHTML = localStorage.getItem("mtext01-02");
      document.getElementById("mdisplay01-03").innerHTML = localStorage.getItem("mtext01-03");
      document.getElementById("mdisplay01-04").innerHTML = localStorage.getItem("mtext01-04");

      document.getElementById("mdisplay02-01").innerHTML = localStorage.getItem("mtext02-01");
      document.getElementById("mdisplay02-02").innerHTML = localStorage.getItem("mtext02-02");
      document.getElementById("mdisplay02-03").innerHTML = localStorage.getItem("mtext02-03");
      document.getElementById("mdisplay02-04").innerHTML = localStorage.getItem("mtext02-04");

      document.getElementById("mdisplay03-01").innerHTML = localStorage.getItem("mtext03-01");
      document.getElementById("mdisplay03-02").innerHTML = localStorage.getItem("mtext03-02");
      document.getElementById("mdisplay03-03").innerHTML = localStorage.getItem("mtext03-03");
      document.getElementById("mdisplay03-04").innerHTML = localStorage.getItem("mtext03-04");

      document.getElementById("mdisplay04-01").innerHTML = localStorage.getItem("mtext04-01");
      document.getElementById("mdisplay04-02").innerHTML = localStorage.getItem("mtext04-02");
      document.getElementById("mdisplay04-03").innerHTML = localStorage.getItem("mtext04-03");
      document.getElementById("mdisplay04-04").innerHTML = localStorage.getItem("mtext04-04");

    } else {
      alert("Incorrect.");
  }
}
// Function to change nav to mobile nav
function myFunction() {
    var x = document.getElementById("mobileNav");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}
