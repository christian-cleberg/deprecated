// display or hide panel
function panelFunction() {
  document.getElementById("id01").style.display = "block";
}

// Distance calculator
function calcDistance() {
  var originLatitude = $("#originLatitude").val();
      originLatitude = parseFloat(originLatitude);
  var originLongitude = $("#originLongitude").val();
      originLongitude = parseFloat(originLongitude);
  var destinationLatitude = $("#destinationLatitude").val();
      destinationLatitude = parseFloat(destinationLatitude);
  var destinationLongitude = $("#destinationLongitude").val();
      destinationLongitude = parseFloat(destinationLongitude);

  if (isNaN(originLatitude) ||
      isNaN(originLongitude) ||
      isNaN(destinationLatitude) ||
      isNaN(destinationLongitude)) {
          alert("Error! One or more of the numbers you entered contained a non-numeric value! Please only enter valid numbers.")
  } else {
      var c = originLatitude * Math.PI / 180;
      var d = originLongitude * Math.PI / 180;
      var e = destinationLatitude * Math.PI / 180;
      var f = destinationLongitude * Math.PI / 180;
      var r = 6371;
      var g = Math.acos(Math.sin(c) * Math.sin(e) + Math.cos(c) * Math.cos(e) * Math.cos(f - d)) * r;
      var h = g.toFixed(2);
      var x = (h * 0.62137);
      var y = x.toFixed(2);
      sessionStorage.setItem("kilos", h);
      $("#outputDistance").val(h + " kilometers");
  }
}

// toggle kg to mi
function conversion() {
  var aa = sessionStorage.getItem("kilos");
  var bb = (aa * 0.62137);
  var cc = bb.toFixed(2);
  $("#outputDistance").val(cc + " miles");
}

//Future value of an investment
function futureValue() {
  var investment = $("#investment").val();
      investment = parseFloat(investment);
  var apr = $("#apr").val();
      apr = parseFloat(apr);
  var yearsAccrued = $("#yearsAccrued").val();
      yearsAccrued = parseFloat(yearsAccrued);
  var n = 12;
  var z = investment * Math.pow( (1 + (apr/n)), (n*yearsAccrued) );
      z = z.toFixed(2);

  if (isNaN(investment) ||
      isNaN(apr) ||
      isNaN(yearsAccrued)) {
    alert("Error! One or more of the values entered was not a number. Please try again.");
  } else {
    $("#futureValue").val("$" + z);
  }
}

function myFunction() {
    var x = document.getElementById("mobileNav");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        $("#mobileNav").slideDown();
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}

// Currency Conversion
function setValue(dollars, exchangeRate) {
  var result = (exchangeRate * dollars).toFixed(2);
  $('#outputCurrencyValue').val(result);
}

function getExchangeRate(from) {
    var to = $('#outputCurrency').val();
    var conversionData = {
        "from": "USD",
        "to": to
    };
    $.ajax({
      type: 'GET',
      url: 'http://cse.unl.edu/~cbourke/CSCE120/proxies/currency.php',
      data: conversionData,
      contentType: "application/json",
      success: function(json) {
          if('rate' in json) {
            var exchangeRate = json.rate;
            var inputValue = $('#inputCurrencyValue').val();
            setValue(inputValue, exchangeRate);
          } else {
            raiseError("Currency Exchange Service did not recognize your parameters...");
            $('#errMsg').css("display", "inline").html("error: unable to determine exchange rate");
          }
      },
      error: function(e) {
        raiseError("There was a problem connecting to the server!");
      }
    });
}

function raiseError(msg) {
  var errorDiv = '<div class="w3-panel w3-red" role="alert"><button class="w3-btn w3-red" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><strong>ERROR!</strong> '+msg+'</div>';
  $('#errMsgArea').empty();
  $('#errMsgArea').append(errorDiv);
  $('#errMsgArea').hide().fadeIn("slow");
}

// Guessing Game
function guessingGame() {
  var min = 1;
  var max = 100;
  //create a random number between 1 and 100
  var mysteryNumber = Math.floor(Math.random() * (max + 1 - min)) + min;

  //prompt the user for input
  var stringGuess = prompt("enter a value");
  //parse the user's guess as an integer
  var guess = parseInt(stringGuess);
  var numGuesses = 1;

  while(guess !== mysteryNumber) {
    if (guess < mysteryNumber) {
      alert("Incorrect. The number you guessed was lower than the correct answer. You have guessed " + numGuesses + " times.");
    } else if (guess > mysteryNumber) {
      alert("Incorrect. The number you guessed was higher than the correct answer. You have guessed " + numGuesses + " times.");
    }
    //prompt the user for input
    var stringGuess = prompt("enter a value");
    //parse the user's guess as an integer
    var guess = parseInt(stringGuess);
    numGuesses += 1;
  }
  if (guess === mysteryNumber) {
    alert("Congratulations! You guessed correctly. It took you " + numGuesses + " tries.");
    $("#answer").val(mysteryNumber);
    $("#numGuesses").val(numGuesses);
  }
}
// reset the boxes to original values
function resetGuessBoxes() {
  $("#answer").val("?");
  $("#numGuesses").val(0);
}
