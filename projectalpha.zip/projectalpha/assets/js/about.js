// display or hide panel
function panelFunction() {
  document.getElementById("id01").style.display = "block";
}

function setVisibility(id) {
  if(document.getElementById('bt1').value=='Hide Layer'){
    document.getElementById('bt1').value = 'Show Layer';
    document.getElementById(id).style.display = 'none';
  }else{
    document.getElementById('bt1').value = 'Hide Layer';
    document.getElementById(id).style.display = 'inline';
  }
}

function setVisibilityB(id) {
  if(document.getElementById('bt2').value=='Hide Layer'){
    document.getElementById('bt2').value = 'Show Layer';
    document.getElementById(id).style.display = 'none';
  }else{
    document.getElementById('bt2').value = 'Hide Layer';
    document.getElementById(id).style.display = 'inline';
  }
}

function myFunction() {
    var x = document.getElementById("mobileNav");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        $("#nav").slideDown();
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}
// to open and close the sidebar
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
