function myFunction() {
    var x = document.getElementById("mobileNav");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}
// display or hide panel
function panelFunction() {
  document.getElementById("id01").style.display = "block";
}
