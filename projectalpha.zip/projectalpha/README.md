# Project Alpha
#### Built by Christian Cleberg

My very first showcase website, built in 2016. This website shows parallax scrolling, slideshows, Google Maps integration, JavaScript programs, sessionStorage, localStorage, and common CSS properties.
