function logVisit() {
  $.post("../../../php/access_log.php").done(function() {
    console.log("This visit has been recorded. Thank you!");
  });
}

function loadPlayers() {
  // Pull Current Data
  $.ajax({
    type: "GET",
    url: "https://api.mysportsfeeds.com/v1.1/pull/nba/2018-2019-regular/active_players.json",
    dataType: 'json',
    async: true,
    headers: {
      "Authorization": "Basic " + btoa("450eb286-f7a5-4474-ae16-afe666" + ":" + "xE3N#3p$mNU4#Ebk")
    },
    success: function(data) {
      // console.log(data.activeplayers);
      var playerObj = data.activeplayers.playerentry;
      for (var i = 0; i < playerObj.length; i++) {
        // console.log(playerObj[i]);
        // Make sure players have an active team
        if (playerObj[i].team != 'undefined' && playerObj[i].team != null) {
          // Create variables for easy editing and aggregation
          var firstName = playerObj[i].player.FirstName;
          if (firstName == 'undefined' || firstName == null) {
            firstName = "";
          }
          var lastName = playerObj[i].player.LastName;
          if (lastName == 'undefined' || lastName == null) {
            lastName = "";
          }
          var imgSrc = playerObj[i].player.officialImageSrc;
          if (imgSrc == 'undefined' || imgSrc == null) {
            imgSrc = "";
          }
          var age = playerObj[i].player.Age;
          if (age == 'undefined' || age == null) {
            age = "";
          }
          var birthDate = playerObj[i].player.BirthDate;
          if (birthDate == 'undefined' || birthDate == null) {
            birthDate = "";
          }
          var height = playerObj[i].player.Height;
          if (height == 'undefined' || height == null) {
            height = "";
          }
          var weight = playerObj[i].player.Weight;
          if (weight == 'undefined' || weight == null) {
            weight = "";
          }
          var position = playerObj[i].player.Position;
          if (position == 'undefined' || position == null) {
            position = "";
          }
          var jerseyNumber = playerObj[i].player.JerseyNumber;
          if (jerseyNumber == 'undefined' || jerseyNumber == null) {
            jerseyNumber = "";
          }
          var rookie = playerObj[i].player.IsRookie;
          if (rookie == 'undefined' || rookie == null) {
            rookie = "";
          }
          var teamAbbr = playerObj[i].team.Abbreviation;
          if (teamAbbr == 'undefined' || teamAbbr == null) {
            teamAbbr = "";
          }
          var teamCity = playerObj[i].team.City;
          if (teamCity == 'undefined' || teamCity == null) {
            teamCity = "";
          }
          var teamName = playerObj[i].team.Name;
          if (teamName == 'undefined' || teamName == null) {
            teamName = "";
          }
          // Rookie Status
          if (rookie == 'true' || rookie == true) {
            var playerRow = "<tr style='border:1px solid red;'><th scope='row'><img class='player-table-img' src='" + imgSrc + "' /></th><th>" + jerseyNumber + "</th><th>" + firstName + " " + lastName + "</th><th>" + position + "</th><th>" + age + "</th><th>" + height + "</th><th>" + weight + "</th><th>" + teamCity + " " + teamName + "</th></tr>";
          } else {
            var playerRow = "<tr><th scope='row'><img class='player-table-img' src='" + imgSrc + "' /></th><th>" + jerseyNumber + "</th><th>" + firstName + " " + lastName + "</th><th>" + position + "</th><th>" + age + "</th><th>" + height + "</th><th>" + weight + "</th><th>" + teamCity + " " + teamName + "</th></tr>";
          }
          $("#all-players-tbody").append(playerRow);
        }
      }
      // Create a data table
      $("#all-players").DataTable({
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        "order": [
          [2, "asc"]
        ]
      });
    }
  });
}