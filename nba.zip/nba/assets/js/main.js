function logVisit() {
  $.post("../../../php/access_log.php").done(function() {
    console.log("This visit has been recorded. Thank you!");
  });
}
// Global Variables
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const EOS = new Date(2019, 04, 10);
var dateObj = new Date();
var month = dateObj.getMonth() + 1;
var day = dateObj.getDate();
var year = dateObj.getFullYear();
var formalDate = months[month - 1] + " " + day + ", " + year;
var formalPreviousDate = months[month - 1] + " " + (day - 1) + ", " + year;

function loadScoreboardData() {
  // If returned dates are single digits, prepend zeroes
  // Day is set to yesterday since live stats are not available
  var day = new Date();
  var today = new Date(year, month, day);
  if (EOS >= today) {
    if (day.toString().length == 1) {
      day = "0" + (day - 1);
    }
    if (month.toString().length == 1) {
      month = "0" + month;
    }
  } else {
    formalPreviousDate = "April 10" + ", " + year;
    formalDate = "April 11" + ", " + year;
    day = "10";
    month = "04";
  }
  var url = "https://api.mysportsfeeds.com/v1.1/pull/nba/2018-2019-regular/scoreboard.json?fordate=" + year + month + day;
  var previousURL = "https://api.mysportsfeeds.com/v1.1/pull/nba/2018-2019-regular/scoreboard.json?fordate=" + year + month + (day - 1);

  // Pull Current Data
  $.ajax({
    type: "GET",
    url: url,
    dataType: 'json',
    async: true,
    headers: {
      "Authorization": "Basic " + btoa("450eb286-f7a5-4474-ae16-afe666" + ":" + "xE3N#3p$mNU4#Ebk")
    },
    success: loadScoreboard
  });

  // Pull Previous Data
  $.ajax({
    type: "GET",
    url: previousURL,
    dataType: 'json',
    async: true,
    headers: {
      "Authorization": "Basic " + btoa("450eb286-f7a5-4474-ae16-afe666" + ":" + "xE3N#3p$mNU4#Ebk")
    },
    success: loadScoreboard
  });
};

function loadScoreboard(data) {
  // Get all games in an array
  if (data == 'undefined' || data == null || data.scoreboard.gameScore == 'undefined' || data.scoreboard.gameScore == null) {
    // Only append if card doesn't already exist
    if (document.getElementById("nodata-card") == null) {
      $(".feed-col-center").append("<div id='nodata-card' class='card text-center'><div class='card-body'><h5 class='card-title'>Sorry! No game data is available yet today.</h5><h6 class='card-subtitle mb-2 text-muted'>Once our data provider releases the data, it will appear here.</h6></div>");
    }
  } else {
    const array = data.scoreboard.gameScore;
    // console.log(array);

    for (var i = 0; i < array.length; i++) {
      // Scores
      var homeScore = array[i].homeScore;
      var awayScore = array[i].awayScore;
      var homeQtrOne = array[i].quarterSummary.quarter[0].homeScore;
      var homeQtrTwo = array[i].quarterSummary.quarter[1].homeScore;
      var homeQtrThree = array[i].quarterSummary.quarter[2].homeScore;
      var homeQtrFour = array[i].quarterSummary.quarter[3].homeScore;
      var awayQtrOne = array[i].quarterSummary.quarter[0].awayScore;
      var awayQtrTwo = array[i].quarterSummary.quarter[1].awayScore;
      var awayQtrThree = array[i].quarterSummary.quarter[2].awayScore;
      var awayQtrFour = array[i].quarterSummary.quarter[3].awayScore;

      // Teams
      var homeCity = array[i].game.homeTeam.City;
      var homeName = array[i].game.homeTeam.Name
      var homeTeam = homeCity + " " + homeName;
      var awayCity = array[i].game.awayTeam.City;
      var awayName = array[i].game.awayTeam.Name
      var awayTeam = awayCity + " " + awayName;

      // Details
      var time = array[i].game.time;
      var location = array[i].game.location;

      var gameCard = "<div class='card text-center'><div class='card-body'><h5 class='card-title'>" + homeName + " vs " + awayName + "</h5><h6 class='card-subtitle mb-2 text-muted'>" + formalPreviousDate + "</h6><p class='card-text scoreboard-score'><img class='team-logo-md noselect' src=./assets/img/teams/" + homeName.replace(/\s/g, '') + ".svg />" + homeScore + " - " + awayScore + "<img class='team-logo-md noselect' src=./assets/img/teams/" + awayName.replace(/\s/g, '') + ".svg /></p></div></div>";
      var gameRowHome = "<div class='d-flex flex-row align-items-center'><img class='team-logo-sm noselect' src=./assets/img/teams/" + homeName.replace(/\s/g, '') + ".svg /><p>" + homeTeam + "</p><p>" + homeScore + "</p></div>";
      var gameRowOpp = "<div class='d-flex flex-row align-items-center'><img class='team-logo-sm noselect' src=./assets/img/teams/" + awayName.replace(/\s/g, '') + ".svg /><p>" + awayTeam + "</p><p>" + awayScore + "</p></div>";
      var gameRow = "<div class='row' style='margin-bottom:0.75rem;border:1px solid #333;'><div class='d-flex flex-column col'>" + gameRowHome + "" + gameRowOpp + "</div><div class='d-flex flex-column col'><div>" + homeQtrOne + " | " + homeQtrTwo + " | " + homeQtrThree + " | " + homeQtrFour + "</div><div>" + awayQtrOne + " | " + awayQtrTwo + " | " + awayQtrThree + " | " + awayQtrFour + "</div></div></div>";
      var centerGameCard = "<div class='col-md-6'><div class='card text-center'><div class='card-body'><h5 class='card-title'>" + homeName + " vs " + awayName + "</h5><h6 class='card-subtitle mb-2 text-muted'>" + formalDate + "</h6><p class='card-text scoreboard-score'><img class='team-logo-md noselect' src=./assets/img/teams/" + homeName.replace(/\s/g, '') + ".svg />" + homeScore + " - " + awayScore + "<img class='team-logo-md noselect' src=./assets/img/teams/" + awayName.replace(/\s/g, '') + ".svg /></p></div></div></div>";
      // Check if game is from yesterday or previous day to sort into the correct column
      if (data.scoreboard.gameScore[i].game.date == (year + "-" + month + "-" + day)) {
        $(".feed-col-center .row").append(centerGameCard);
      } else {
        $(".feed-col-left").append(gameCard);
      }
    }
  }
};

function loadStandingsData() {
  // Pull Previous Data
  $.ajax({
    type: "GET",
    url: "https://api.mysportsfeeds.com/v1.1/pull/nba/2018-2019-regular/overall_team_standings.json",
    dataType: 'json',
    async: true,
    headers: {
      "Authorization": "Basic " + btoa("450eb286-f7a5-4474-ae16-afe666" + ":" + "xE3N#3p$mNU4#Ebk")
    },
    success: loadStandings
  });
};

function loadStandings(data) {
  // Get all games in an array
  const array = data.overallteamstandings.teamstandingsentry;
  // console.log(array);

  for (var i = 0; i < array.length; i++) {
    var team = array[i].team.Abbreviation;
    var wins = array[i].stats.Wins["#text"];
    var losses = array[i].stats.Losses["#text"];
    var gamesBack = array[i].stats.GamesBack["#text"];

    var standing = "<div class='d-flex flex-row justify-content-between'><p>" + (i + 1) + "</p><p>" + team + "</p><p>" + wins + "</p><p>" + losses + "</p><p>" + gamesBack + "</p></div>";
    $(".feed-col-right .card-body").append(standing);
  }
};