mapboxgl.accessToken = 'pk.eyJ1IjoiY2hyaXN0aWFuY2xlYmVyZyIsImEiOiJjajd3eDMxY3UweTZsMzJzNjdqeDB5ZWNwIn0.WF-eOosIjGsI_QJBJTMi-w';
var map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [-96.70, 40.81], // starting position [lng, lat] - Lincoln, NE
  zoom: 12 // starting zoom shows entire USA
});

var geocoder = new MapboxGeocoder({ // Initialize the geocoder
  accessToken: mapboxgl.accessToken, // Set the access token
  placeholder: 'Search'
  /* , bbox: [-122.30937, 37.84214, -122.23715, 37.89838], // Set boundaries to contain search results
       proximity: { longitude: -122.25948, latitude: 37.87221 } // Coordinates for search area */
});
// Add the geocoder to the map
map.addControl(geocoder);

// Add zoom and rotation controls to the map.
map.addControl(new mapboxgl.NavigationControl());
// Add navigation controls to the map.
map.addControl(new MapboxDirections({
  accessToken: mapboxgl.accessToken
}), 'top-left');
// Add geolocate control to the map.
map.addControl(new mapboxgl.GeolocateControl({
  positionOptions: {
    enableHighAccuracy: true
  },
  trackUserLocation: true
}));
