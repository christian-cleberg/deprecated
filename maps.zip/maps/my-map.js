mapboxgl.accessToken = 'pk.eyJ1IjoiY2hyaXN0aWFuY2xlYmVyZyIsImEiOiJjajd3eDMxY3UweTZsMzJzNjdqeDB5ZWNwIn0.WF-eOosIjGsI_QJBJTMi-w';
var map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [-96.70, 40.81], // starting position [lng, lat] - Lincoln, NE
  zoom: 3.5 // starting zoom shows entire USA
});

// Add zoom and rotation controls to the map.
map.addControl(new mapboxgl.NavigationControl());
// Add navigation controls to the map.
map.addControl(new MapboxDirections({
  accessToken: mapboxgl.accessToken
}), 'top-left');
// Add geolocate control to the map.
map.addControl(new mapboxgl.GeolocateControl({
  positionOptions: {
    enableHighAccuracy: true
  },
  trackUserLocation: true
}));

var placesLived = {
  type: 'FeatureCollection',
  features: [{
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-103.723892, 44.380920]
    },
    properties: {
      title: 'Mapbox',
      description: 'Deadwood, SD'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-94.871706, 43.638510]
    },
    properties: {
      title: 'Mapbox',
      description: 'Alpha, MN'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-96.702606, 40.813599]
    },
    properties: {
      title: 'Mapbox',
      description: 'Lincoln, NE'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-105.494232, 44.293140]
    },
    properties: {
      title: 'Mapbox',
      description: 'Gillette, WY'
    }
  }]
};

// add markers to map
placesLived.features.forEach(function(marker) {

  // create a HTML element for each feature
  var el = document.createElement('div');
  el.className = 'marker-home';

  // make a marker for each feature and add to the map
  new mapboxgl.Marker(el)
    .setLngLat(marker.geometry.coordinates)
    .addTo(map);
});

var placesVisited = {
  type: 'FeatureCollection',
  features: [{
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-96.731300, 43.547310]
    },
    properties: {
      title: 'Mapbox',
      description: 'Sioux Falls, SD'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-93.264374, 44.977489]
    },
    properties: {
      title: 'Mapbox',
      description: 'Minneapolis, MN'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-87.629799, 41.878113]
    },
    properties: {
      title: 'Mapbox',
      description: 'Chicago, IL'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-96.789803, 46.877186]
    },
    properties: {
      title: 'Mapbox',
      description: 'Fargo, ND'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-96.406440, 42.496320]
    },
    properties: {
      title: 'Mapbox',
      description: 'Sioux City, IA'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-95.937187, 41.258652]
    },
    properties: {
      title: 'Mapbox',
      description: 'Omaha, NE'
    }
  },,
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-98.351410, 40.920030]
    },
    properties: {
      title: 'Mapbox',
      description: 'Grand Island, NE'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-94.879660, 47.472650]
    },
    properties: {
      title: 'Mapbox',
      description: 'Bemidji, MN'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-92.458870, 44.019329]
    },
    properties: {
      title: 'Mapbox',
      description: 'Rochester, MN'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-93.620308, 41.588821]
    },
    properties: {
      title: 'Mapbox',
      description: 'Des Moines, IA'
    }
  },,
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-91.669861, 41.978050]
    },
    properties: {
      title: 'Mapbox',
      description: 'Cedar Rapids, IA'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-91.251860, 43.808770]
    },
    properties: {
      title: 'Mapbox',
      description: 'La Crosse, WI'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-87.789460, 42.726130]
    },
    properties: {
      title: 'Mapbox',
      description: 'Racine, WI'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-87.909416, 43.041069]
    },
    properties: {
      title: 'Mapbox',
      description: 'Milwaukee, WI'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-98.488068, 45.465141]
    },
    properties: {
      title: 'Mapbox',
      description: 'Aberdeen, SD'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-103.224457, 44.082989]
    },
    properties: {
      title: 'Mapbox',
      description: 'Rapid City, SD'
    }
  },,
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-104.374670, 44.405880]
    },
    properties: {
      title: 'Mapbox',
      description: 'Sundance, WY'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-104.984848, 39.738449]
    },
    properties: {
      title: 'Mapbox',
      description: 'Denver, CO'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-111.888138, 40.758480]
    },
    properties: {
      title: 'Mapbox',
      description: 'Salt Lake City, UT'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-115.140579, 36.169090]
    },
    properties: {
      title: 'Mapbox',
      description: 'Las Vegas, NV'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-118.243683, 34.05235]
    },
    properties: {
      title: 'Mapbox',
      description: 'Los Angeles, CA'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-117.163818, 32.715759]
    },
    properties: {
      title: 'Mapbox',
      description: 'San Diego, CA'
    }
  },
  {
    type: 'Feature',
    geometry: {
      type: 'Point',
      coordinates: [-117.915642, 33.834492]
    },
    properties: {
      title: 'Mapbox',
      description: 'Anaheim, CA'
    }
  }]
};

// add markers to map
placesVisited.features.forEach(function(marker) {

  // create a HTML element for each feature
  var el = document.createElement('div');
  el.className = 'marker';

  // make a marker for each feature and add to the map
  new mapboxgl.Marker(el)
    .setLngLat(marker.geometry.coordinates)
    .addTo(map);
});
